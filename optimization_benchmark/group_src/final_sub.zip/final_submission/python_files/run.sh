nohup python data_gen.py exp_opt > exp_opt.out 2> exp_opt.err &
nohup python data_gen.py global_opt > global.out 2> global.err &
nohup python data_gen.py local_opt > local_opt.out 2> local_opt.err &
nohup python data_gen.py pop_opt > pop.out 2> pop.err &
nohup python data_gen.py smb_opt > smb.out 2> smd.err &